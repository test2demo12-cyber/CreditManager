package com.creditmanager.models;

public class Customer {
    private int id;
    private String name;
    private String contact;
    private String details;
    private String createdAt;

    public Customer() {}

    public Customer(String name, String contact, String details) {
        this.name = name;
        this.contact = contact;
        this.details = details;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getContact() { return contact; }
    public void setContact(String contact) { this.contact = contact; }
    public String getDetails() { return details; }
    public void setDetails(String details) { this.details = details; }
    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }

    @Override
    public String toString() { return name; }
}
