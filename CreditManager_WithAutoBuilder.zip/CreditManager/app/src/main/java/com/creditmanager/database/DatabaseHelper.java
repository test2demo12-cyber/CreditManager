package com.creditmanager.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.creditmanager.models.Credit;
import com.creditmanager.models.Customer;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "CreditManager.db";
    private static final int DATABASE_VERSION = 1;

    // Customer Table
    public static final String TABLE_CUSTOMERS = "customers";
    public static final String COL_CUST_ID = "id";
    public static final String COL_CUST_NAME = "name";
    public static final String COL_CUST_CONTACT = "contact";
    public static final String COL_CUST_DETAILS = "details";
    public static final String COL_CUST_CREATED_AT = "created_at";

    // Credit Table
    public static final String TABLE_CREDITS = "credits";
    public static final String COL_CREDIT_ID = "id";
    public static final String COL_CREDIT_CUSTOMER_ID = "customer_id";
    public static final String COL_CREDIT_AMOUNT = "amount";
    public static final String COL_CREDIT_DESCRIPTION = "description";
    public static final String COL_CREDIT_DATE = "date";
    public static final String COL_CREDIT_CREATED_AT = "created_at";

    private static DatabaseHelper instance;

    public static synchronized DatabaseHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseHelper(context.getApplicationContext());
        }
        return instance;
    }

    private DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createCustomers = "CREATE TABLE " + TABLE_CUSTOMERS + " (" +
                COL_CUST_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_CUST_NAME + " TEXT NOT NULL, " +
                COL_CUST_CONTACT + " TEXT, " +
                COL_CUST_DETAILS + " TEXT, " +
                COL_CUST_CREATED_AT + " TEXT DEFAULT (datetime('now','localtime'))" +
                ")";

        String createCredits = "CREATE TABLE " + TABLE_CREDITS + " (" +
                COL_CREDIT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_CREDIT_CUSTOMER_ID + " INTEGER NOT NULL, " +
                COL_CREDIT_AMOUNT + " REAL NOT NULL, " +
                COL_CREDIT_DESCRIPTION + " TEXT, " +
                COL_CREDIT_DATE + " TEXT NOT NULL, " +
                COL_CREDIT_CREATED_AT + " TEXT DEFAULT (datetime('now','localtime')), " +
                "FOREIGN KEY(" + COL_CREDIT_CUSTOMER_ID + ") REFERENCES " + TABLE_CUSTOMERS + "(" + COL_CUST_ID + ")" +
                ")";

        db.execSQL(createCustomers);
        db.execSQL(createCredits);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CREDITS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CUSTOMERS);
        onCreate(db);
    }

    // ===================== CUSTOMER OPERATIONS =====================

    public long addCustomer(Customer customer) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_CUST_NAME, customer.getName());
        values.put(COL_CUST_CONTACT, customer.getContact());
        values.put(COL_CUST_DETAILS, customer.getDetails());
        long id = db.insert(TABLE_CUSTOMERS, null, values);
        db.close();
        return id;
    }

    public boolean customerExists(String name) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_CUSTOMERS,
                new String[]{COL_CUST_ID},
                COL_CUST_NAME + "=? COLLATE NOCASE",
                new String[]{name}, null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    public List<Customer> getAllCustomers() {
        List<Customer> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_CUSTOMERS + " ORDER BY " + COL_CUST_NAME + " ASC", null);
        if (cursor.moveToFirst()) {
            do {
                Customer c = new Customer();
                c.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COL_CUST_ID)));
                c.setName(cursor.getString(cursor.getColumnIndexOrThrow(COL_CUST_NAME)));
                c.setContact(cursor.getString(cursor.getColumnIndexOrThrow(COL_CUST_CONTACT)));
                c.setDetails(cursor.getString(cursor.getColumnIndexOrThrow(COL_CUST_DETAILS)));
                c.setCreatedAt(cursor.getString(cursor.getColumnIndexOrThrow(COL_CUST_CREATED_AT)));
                list.add(c);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return list;
    }

    // ===================== CREDIT OPERATIONS =====================

    public long addCredit(Credit credit) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_CREDIT_CUSTOMER_ID, credit.getCustomerId());
        values.put(COL_CREDIT_AMOUNT, credit.getAmount());
        values.put(COL_CREDIT_DESCRIPTION, credit.getDescription());
        values.put(COL_CREDIT_DATE, credit.getDate());
        long id = db.insert(TABLE_CREDITS, null, values);
        db.close();
        return id;
    }

    public double getTotalCreditByCustomer(int customerId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT SUM(" + COL_CREDIT_AMOUNT + ") FROM " + TABLE_CREDITS +
                        " WHERE " + COL_CREDIT_CUSTOMER_ID + "=?",
                new String[]{String.valueOf(customerId)});
        double total = 0;
        if (cursor.moveToFirst()) total = cursor.getDouble(0);
        cursor.close();
        db.close();
        return total;
    }

    public double getTodayTotalCredit() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT SUM(" + COL_CREDIT_AMOUNT + ") FROM " + TABLE_CREDITS +
                        " WHERE " + COL_CREDIT_DATE + " = date('now','localtime')", null);
        double total = 0;
        if (cursor.moveToFirst()) total = cursor.getDouble(0);
        cursor.close();
        db.close();
        return total;
    }

    public double getMonthTotalCredit() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT SUM(" + COL_CREDIT_AMOUNT + ") FROM " + TABLE_CREDITS +
                        " WHERE strftime('%Y-%m', " + COL_CREDIT_DATE + ") = strftime('%Y-%m', 'now','localtime')", null);
        double total = 0;
        if (cursor.moveToFirst()) total = cursor.getDouble(0);
        cursor.close();
        db.close();
        return total;
    }

    public double getAllTimeTotal() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT SUM(" + COL_CREDIT_AMOUNT + ") FROM " + TABLE_CREDITS, null);
        double total = 0;
        if (cursor.moveToFirst()) total = cursor.getDouble(0);
        cursor.close();
        db.close();
        return total;
    }

    public List<Credit> getCreditsByCustomer(int customerId) {
        List<Credit> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_CREDITS +
                        " WHERE " + COL_CREDIT_CUSTOMER_ID + "=?" +
                        " ORDER BY " + COL_CREDIT_DATE + " DESC",
                new String[]{String.valueOf(customerId)});
        if (cursor.moveToFirst()) {
            do {
                Credit credit = buildCredit(cursor);
                list.add(credit);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return list;
    }

    public List<Object[]> getCustomerSummary() {
        // Returns [customerId, customerName, contact, totalCredit]
        List<Object[]> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT c." + COL_CUST_ID + ", c." + COL_CUST_NAME + ", c." + COL_CUST_CONTACT +
                        ", COALESCE(SUM(cr." + COL_CREDIT_AMOUNT + "), 0) as total" +
                        " FROM " + TABLE_CUSTOMERS + " c" +
                        " LEFT JOIN " + TABLE_CREDITS + " cr ON c." + COL_CUST_ID + " = cr." + COL_CREDIT_CUSTOMER_ID +
                        " GROUP BY c." + COL_CUST_ID +
                        " ORDER BY c." + COL_CUST_NAME + " ASC", null);
        if (cursor.moveToFirst()) {
            do {
                Object[] row = new Object[4];
                row[0] = cursor.getInt(0);
                row[1] = cursor.getString(1);
                row[2] = cursor.getString(2);
                row[3] = cursor.getDouble(3);
                list.add(row);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return list;
    }

    public List<Credit> getAllCredits() {
        List<Credit> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT cr.*, c." + COL_CUST_NAME + " FROM " + TABLE_CREDITS + " cr" +
                        " JOIN " + TABLE_CUSTOMERS + " c ON cr." + COL_CREDIT_CUSTOMER_ID + " = c." + COL_CUST_ID +
                        " ORDER BY cr." + COL_CREDIT_DATE + " DESC", null);
        if (cursor.moveToFirst()) {
            do {
                Credit credit = buildCredit(cursor);
                try {
                    credit.setCustomerName(cursor.getString(cursor.getColumnIndexOrThrow(COL_CUST_NAME)));
                } catch (Exception ignored) {}
                list.add(credit);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return list;
    }

    private Credit buildCredit(Cursor cursor) {
        Credit credit = new Credit();
        credit.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COL_CREDIT_ID)));
        credit.setCustomerId(cursor.getInt(cursor.getColumnIndexOrThrow(COL_CREDIT_CUSTOMER_ID)));
        credit.setAmount(cursor.getDouble(cursor.getColumnIndexOrThrow(COL_CREDIT_AMOUNT)));
        credit.setDescription(cursor.getString(cursor.getColumnIndexOrThrow(COL_CREDIT_DESCRIPTION)));
        credit.setDate(cursor.getString(cursor.getColumnIndexOrThrow(COL_CREDIT_DATE)));
        credit.setCreatedAt(cursor.getString(cursor.getColumnIndexOrThrow(COL_CREDIT_CREATED_AT)));
        return credit;
    }

    // For import - add customer or get existing
    public int addOrGetCustomer(String name, String contact, String details) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.query(TABLE_CUSTOMERS, new String[]{COL_CUST_ID},
                COL_CUST_NAME + "=? COLLATE NOCASE", new String[]{name}, null, null, null);
        if (cursor.moveToFirst()) {
            int id = cursor.getInt(0);
            cursor.close();
            db.close();
            return id;
        }
        cursor.close();
        ContentValues values = new ContentValues();
        values.put(COL_CUST_NAME, name);
        values.put(COL_CUST_CONTACT, contact);
        values.put(COL_CUST_DETAILS, details);
        long id = db.insert(TABLE_CUSTOMERS, null, values);
        db.close();
        return (int) id;
    }
}
