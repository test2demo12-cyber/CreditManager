package com.creditmanager.activities;

import android.app.Dialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Window;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.creditmanager.R;
import com.creditmanager.database.DatabaseHelper;
import com.creditmanager.models.Credit;
import com.creditmanager.models.Customer;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AddCreditActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private AutoCompleteTextView spinnerCustomer;
    private TextInputEditText etAmount, etDescription;
    private TextView tvTotalCredit;
    private List<Customer> customerList = new ArrayList<>();
    private Customer selectedCustomer = null;
    private DecimalFormat df = new DecimalFormat("#,##0.00");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_credit);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Add Credit");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        db = DatabaseHelper.getInstance(this);

        spinnerCustomer = findViewById(R.id.spinner_customer);
        etAmount = findViewById(R.id.et_amount);
        etDescription = findViewById(R.id.et_description);
        tvTotalCredit = findViewById(R.id.tv_total_credit);
        MaterialButton btnAddCustomer = findViewById(R.id.btn_add_customer);
        MaterialButton btnAddCredit = findViewById(R.id.btn_add_credit);

        loadCustomers();

        btnAddCustomer.setOnClickListener(v -> showAddCustomerDialog());
        btnAddCredit.setOnClickListener(v -> addCredit());

        spinnerCustomer.setOnItemClickListener((parent, view, position, id) -> {
            selectedCustomer = customerList.get(position);
            updateTotalCredit();
        });
    }

    private void loadCustomers() {
        customerList = db.getAllCustomers();
        List<String> names = new ArrayList<>();
        for (Customer c : customerList) names.add(c.getName());
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, names);
        spinnerCustomer.setAdapter(adapter);
        spinnerCustomer.setThreshold(0);
    }

    private void updateTotalCredit() {
        if (selectedCustomer != null) {
            double total = db.getTotalCreditByCustomer(selectedCustomer.getId());
            tvTotalCredit.setText("Total Credit: ₹ " + df.format(total));
        }
    }

    private void addCredit() {
        if (selectedCustomer == null) {
            Toast.makeText(this, "Please select a customer", Toast.LENGTH_SHORT).show();
            return;
        }
        String amountStr = etAmount.getText().toString().trim();
        if (amountStr.isEmpty()) {
            Toast.makeText(this, "Please enter amount", Toast.LENGTH_SHORT).show();
            return;
        }
        double amount;
        try {
            amount = Double.parseDouble(amountStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid amount", Toast.LENGTH_SHORT).show();
            return;
        }
        if (amount <= 0) {
            Toast.makeText(this, "Amount must be greater than 0", Toast.LENGTH_SHORT).show();
            return;
        }

        Credit credit = new Credit();
        credit.setCustomerId(selectedCustomer.getId());
        credit.setAmount(amount);
        credit.setDescription(etDescription.getText().toString().trim());
        credit.setDate(new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date()));

        long result = db.addCredit(credit);
        if (result != -1) {
            Toast.makeText(this, "Credit added successfully!", Toast.LENGTH_SHORT).show();
            etAmount.setText("");
            etDescription.setText("");
            updateTotalCredit();
        } else {
            Toast.makeText(this, "Failed to add credit", Toast.LENGTH_SHORT).show();
        }
    }

    private void showAddCustomerDialog() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_add_customer);
        dialog.getWindow().setLayout(
                (int) (getResources().getDisplayMetrics().widthPixels * 0.9),
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT);

        TextInputEditText etName = dialog.findViewById(R.id.et_customer_name);
        TextInputEditText etContact = dialog.findViewById(R.id.et_customer_contact);
        TextInputEditText etDetails = dialog.findViewById(R.id.et_customer_details);
        MaterialButton btnSave = dialog.findViewById(R.id.btn_save_customer);
        MaterialButton btnCancel = dialog.findViewById(R.id.btn_cancel);

        btnCancel.setOnClickListener(v -> dialog.dismiss());

        btnSave.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String contact = etContact.getText().toString().trim();
            String details = etDetails.getText().toString().trim();

            if (name.isEmpty()) {
                etName.setError("Name is required");
                return;
            }
            if (!contact.isEmpty() && !contact.matches("\\d{10}")) {
                etContact.setError("Enter valid 10-digit number");
                return;
            }
            if (db.customerExists(name)) {
                etName.setError("Customer already exists");
                return;
            }

            Customer customer = new Customer(name, contact, details);
            long id = db.addCustomer(customer);
            if (id != -1) {
                Toast.makeText(this, "Customer added!", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
                loadCustomers();
            } else {
                Toast.makeText(this, "Failed to add customer", Toast.LENGTH_SHORT).show();
            }
        });

        dialog.show();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
