package com.creditmanager.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.creditmanager.R;
import com.creditmanager.activities.CustomerHistoryActivity;

import java.text.DecimalFormat;
import java.util.List;

public class CustomerSummaryAdapter extends RecyclerView.Adapter<CustomerSummaryAdapter.ViewHolder> {

    public interface OnCustomerClickListener {
        void onCustomerClick(int customerId);
    }

    private Context context;
    private List<Object[]> data;
    private OnCustomerClickListener listener;
    private DecimalFormat df = new DecimalFormat("#,##0.00");

    public CustomerSummaryAdapter(Context context, List<Object[]> data, OnCustomerClickListener listener) {
        this.context = context;
        this.data = data;
        this.listener = listener;
    }

    public void updateData(List<Object[]> newData) {
        this.data = newData;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_customer_summary, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Object[] row = data.get(position);
        int id = (int) row[0];
        String name = (String) row[1];
        String contact = (String) row[2];
        double total = (double) row[3];

        holder.tvName.setText(name);
        holder.tvContact.setText(contact != null && !contact.isEmpty() ? contact : "No contact");
        holder.tvTotal.setText("₹ " + df.format(total));

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, CustomerHistoryActivity.class);
            intent.putExtra("customer_id", id);
            intent.putExtra("customer_name", name);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() { return data.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvContact, tvTotal;
        ViewHolder(View v) {
            super(v);
            tvName = v.findViewById(R.id.tv_name);
            tvContact = v.findViewById(R.id.tv_contact);
            tvTotal = v.findViewById(R.id.tv_total);
        }
    }
}
