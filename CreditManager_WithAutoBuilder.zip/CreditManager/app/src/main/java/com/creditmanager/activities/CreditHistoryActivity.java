package com.creditmanager.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.creditmanager.R;
import com.creditmanager.adapters.CustomerSummaryAdapter;
import com.creditmanager.database.DatabaseHelper;
import com.creditmanager.models.Credit;
import com.creditmanager.models.Customer;
import com.creditmanager.utils.ExcelUtils;
import com.google.android.material.button.MaterialButton;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class CreditHistoryActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private RecyclerView recyclerView;
    private CustomerSummaryAdapter adapter;
    private List<Object[]> fullList = new ArrayList<>();
    private EditText etSearch;

    private ActivityResultLauncher<Intent> importLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_credit_history);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Credit History");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        db = DatabaseHelper.getInstance(this);
        recyclerView = findViewById(R.id.recycler_customers);
        etSearch = findViewById(R.id.et_search);
        MaterialButton btnExport = findViewById(R.id.btn_export);
        MaterialButton btnImport = findViewById(R.id.btn_import);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        importLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Uri uri = result.getData().getData();
                        importExcel(uri);
                    }
                });

        adapter = new CustomerSummaryAdapter(this, new ArrayList<>(), customerId -> {
            Intent intent = new Intent(this, CustomerHistoryActivity.class);
            intent.putExtra("customer_id", customerId);
            startActivity(intent);
        });
        recyclerView.setAdapter(adapter);

        etSearch.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {}
            public void onTextChanged(CharSequence s, int i, int i1, int i2) { filterList(s.toString()); }
            public void afterTextChanged(Editable e) {}
        });

        btnExport.setOnClickListener(v -> exportExcel());
        btnImport.setOnClickListener(v -> pickExcelFile());

        loadData();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadData();
    }

    private void loadData() {
        fullList = db.getCustomerSummary();
        filterList(etSearch.getText().toString());
    }

    private void filterList(String query) {
        List<Object[]> filtered = new ArrayList<>();
        for (Object[] row : fullList) {
            if (query.isEmpty() || ((String) row[1]).toLowerCase().contains(query.toLowerCase())) {
                filtered.add(row);
            }
        }
        adapter.updateData(filtered);
    }

    private void exportExcel() {
        try {
            File file = ExcelUtils.exportToExcel(this, db);
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(shareIntent, "Export Excel"));
        } catch (Exception e) {
            Toast.makeText(this, "Export failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void pickExcelFile() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        importLauncher.launch(intent);
    }

    private void importExcel(Uri uri) {
        try {
            int count = ExcelUtils.importFromExcel(this, db, uri);
            Toast.makeText(this, "Imported " + count + " records successfully!", Toast.LENGTH_LONG).show();
            loadData();
        } catch (Exception e) {
            Toast.makeText(this, "Import failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
