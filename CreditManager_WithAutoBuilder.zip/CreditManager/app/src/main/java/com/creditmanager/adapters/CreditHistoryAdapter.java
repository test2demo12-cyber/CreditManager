package com.creditmanager.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.creditmanager.R;
import com.creditmanager.models.Credit;

import java.text.DecimalFormat;
import java.util.List;

public class CreditHistoryAdapter extends RecyclerView.Adapter<CreditHistoryAdapter.ViewHolder> {

    private List<Credit> credits;
    private DecimalFormat df = new DecimalFormat("#,##0.00");

    public CreditHistoryAdapter(List<Credit> credits) {
        this.credits = credits;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_credit_history, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Credit c = credits.get(position);
        holder.tvAmount.setText("₹ " + df.format(c.getAmount()));
        holder.tvDate.setText(c.getDate());
        String desc = c.getDescription();
        holder.tvDescription.setText(desc != null && !desc.isEmpty() ? desc : "-");
        if (c.getCustomerName() != null) {
            holder.tvCustomer.setVisibility(View.VISIBLE);
            holder.tvCustomer.setText(c.getCustomerName());
        } else {
            holder.tvCustomer.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() { return credits.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvAmount, tvDate, tvDescription, tvCustomer;
        ViewHolder(View v) {
            super(v);
            tvAmount = v.findViewById(R.id.tv_amount);
            tvDate = v.findViewById(R.id.tv_date);
            tvDescription = v.findViewById(R.id.tv_description);
            tvCustomer = v.findViewById(R.id.tv_customer);
        }
    }
}
