package com.creditmanager.utils;

import android.content.Context;
import android.net.Uri;

import com.creditmanager.database.DatabaseHelper;
import com.creditmanager.models.Credit;
import com.creditmanager.models.Customer;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class ExcelUtils {

    public static File exportToExcel(Context context, DatabaseHelper db) throws Exception {
        Workbook workbook = new XSSFWorkbook();

        // Sheet 1: Customer Summary
        Sheet summarySheet = workbook.createSheet("Customer Summary");
        Row headerRow = summarySheet.createRow(0);
        headerRow.createCell(0).setCellValue("ID");
        headerRow.createCell(1).setCellValue("Customer Name");
        headerRow.createCell(2).setCellValue("Contact");
        headerRow.createCell(3).setCellValue("Total Credit (₹)");

        List<Object[]> summary = db.getCustomerSummary();
        int rowNum = 1;
        for (Object[] row : summary) {
            Row r = summarySheet.createRow(rowNum++);
            r.createCell(0).setCellValue((int) row[0]);
            r.createCell(1).setCellValue((String) row[1]);
            String contact = (String) row[2];
            r.createCell(2).setCellValue(contact != null ? contact : "");
            r.createCell(3).setCellValue((double) row[3]);
        }

        // Sheet 2: All Credits
        Sheet creditsSheet = workbook.createSheet("Credit Details");
        Row creditHeader = creditsSheet.createRow(0);
        creditHeader.createCell(0).setCellValue("ID");
        creditHeader.createCell(1).setCellValue("Customer Name");
        creditHeader.createCell(2).setCellValue("Amount (₹)");
        creditHeader.createCell(3).setCellValue("Date");
        creditHeader.createCell(4).setCellValue("Description");

        List<Credit> credits = db.getAllCredits();
        rowNum = 1;
        for (Credit c : credits) {
            Row r = creditsSheet.createRow(rowNum++);
            r.createCell(0).setCellValue(c.getId());
            r.createCell(1).setCellValue(c.getCustomerName() != null ? c.getCustomerName() : "");
            r.createCell(2).setCellValue(c.getAmount());
            r.createCell(3).setCellValue(c.getDate());
            r.createCell(4).setCellValue(c.getDescription() != null ? c.getDescription() : "");
        }

        // Sheet 3: Customers Master (for import template)
        Sheet custSheet = workbook.createSheet("Customers");
        Row custHeader = custSheet.createRow(0);
        custHeader.createCell(0).setCellValue("Name");
        custHeader.createCell(1).setCellValue("Contact");
        custHeader.createCell(2).setCellValue("Details");

        List<Customer> customers = db.getAllCustomers();
        rowNum = 1;
        for (Customer c : customers) {
            Row r = custSheet.createRow(rowNum++);
            r.createCell(0).setCellValue(c.getName());
            r.createCell(1).setCellValue(c.getContact() != null ? c.getContact() : "");
            r.createCell(2).setCellValue(c.getDetails() != null ? c.getDetails() : "");
        }

        // Auto-size columns
        for (int i = 0; i < 5; i++) {
            summarySheet.autoSizeColumn(i);
            creditsSheet.autoSizeColumn(i);
        }

        String fileName = "CreditManager_" +
                new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date()) + ".xlsx";
        File outputDir = context.getExternalFilesDir(null);
        File file = new File(outputDir, fileName);

        try (FileOutputStream fos = new FileOutputStream(file)) {
            workbook.write(fos);
        }
        workbook.close();
        return file;
    }

    /**
     * Import from Excel - expects sheet named "Credit Details" or first sheet
     * Columns: Customer Name, Amount, Date (yyyy-MM-dd), Description
     */
    public static int importFromExcel(Context context, DatabaseHelper db, Uri uri) throws Exception {
        InputStream inputStream = context.getContentResolver().openInputStream(uri);
        Workbook workbook = new XSSFWorkbook(inputStream);

        // Try to find Credit Details sheet, else use first sheet
        Sheet sheet = workbook.getSheet("Credit Details");
        if (sheet == null) sheet = workbook.getSheetAt(0);

        int count = 0;
        DataFormatter formatter = new DataFormatter();

        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            if (row == null) continue;

            String customerName = formatter.formatCellValue(row.getCell(1));
            String amountStr = formatter.formatCellValue(row.getCell(2));
            String date = formatter.formatCellValue(row.getCell(3));
            String description = row.getCell(4) != null ? formatter.formatCellValue(row.getCell(4)) : "";

            if (customerName.isEmpty() || amountStr.isEmpty()) continue;

            double amount;
            try { amount = Double.parseDouble(amountStr); } catch (Exception e) { continue; }

            if (date.isEmpty()) {
                date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
            }

            int customerId = db.addOrGetCustomer(customerName, "", "");
            if (customerId == -1) continue;

            Credit credit = new Credit();
            credit.setCustomerId(customerId);
            credit.setAmount(amount);
            credit.setDate(date);
            credit.setDescription(description);
            db.addCredit(credit);
            count++;
        }

        workbook.close();
        if (inputStream != null) inputStream.close();
        return count;
    }
}
