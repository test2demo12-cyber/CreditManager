package com.creditmanager.activities;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.creditmanager.R;
import com.creditmanager.adapters.CreditHistoryAdapter;
import com.creditmanager.database.DatabaseHelper;
import com.creditmanager.models.Credit;

import java.text.DecimalFormat;
import java.util.List;

public class CustomerHistoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_history);

        int customerId = getIntent().getIntExtra("customer_id", -1);
        String customerName = getIntent().getStringExtra("customer_name");

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(customerName != null ? customerName : "Customer History");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        if (customerId == -1) { finish(); return; }

        DatabaseHelper db = DatabaseHelper.getInstance(this);
        List<Credit> credits = db.getCreditsByCustomer(customerId);
        double total = db.getTotalCreditByCustomer(customerId);

        TextView tvTotal = findViewById(R.id.tv_total);
        tvTotal.setText("Total Credit: ₹ " + new DecimalFormat("#,##0.00").format(total));

        RecyclerView recyclerView = findViewById(R.id.recycler_credits);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new CreditHistoryAdapter(credits));
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
