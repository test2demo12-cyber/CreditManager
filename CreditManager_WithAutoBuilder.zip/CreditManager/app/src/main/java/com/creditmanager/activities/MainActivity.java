package com.creditmanager.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.creditmanager.R;
import com.creditmanager.database.DatabaseHelper;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private TextView tvTodayTotal, tvMonthTotal, tvAllTimeTotal;
    private DecimalFormat df = new DecimalFormat("#,##0.00");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = DatabaseHelper.getInstance(this);

        tvTodayTotal = findViewById(R.id.tv_today_total);
        tvMonthTotal = findViewById(R.id.tv_month_total);
        tvAllTimeTotal = findViewById(R.id.tv_all_time_total);

        MaterialButton btnAddCredit = findViewById(R.id.btn_add_credit);
        MaterialButton btnCreditHistory = findViewById(R.id.btn_credit_history);

        btnAddCredit.setOnClickListener(v ->
                startActivity(new Intent(this, AddCreditActivity.class)));

        btnCreditHistory.setOnClickListener(v ->
                startActivity(new Intent(this, CreditHistoryActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadDashboard();
    }

    private void loadDashboard() {
        tvTodayTotal.setText("₹ " + df.format(db.getTodayTotalCredit()));
        tvMonthTotal.setText("₹ " + df.format(db.getMonthTotalCredit()));
        tvAllTimeTotal.setText("₹ " + df.format(db.getAllTimeTotal()));
    }
}
